package com.example.demo.service;

import com.example.demo.dto.UserDTO;

public interface UserService {

    String saveUser(UserDTO userDTO);
}
