package com.example.demo.repo;

public interface notification {
}
