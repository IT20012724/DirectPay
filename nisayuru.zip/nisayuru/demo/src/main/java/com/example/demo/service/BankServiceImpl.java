package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class BankServiceImpl implements BankService{

    @Override
    public void setOTP(String otp) {
        System.out.println(otp);
    }
}
