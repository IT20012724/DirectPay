package com.example.demo.service;

import com.example.demo.dto.UserDTO;
import com.example.demo.repo.UserRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional

public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private BankService bankService;
    public String saveUser(UserDTO userDTO){
        bankService.setOTP(userDTO.getOtp());
        return userDTO.getOtp();
//        userRepo.save(userDTO);

    }
}
