package com.example.demo.service;

public interface BankService {
    void setOTP(String otp);
}
