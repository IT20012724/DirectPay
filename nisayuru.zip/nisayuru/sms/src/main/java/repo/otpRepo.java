package repo;


public interface otpRepo {
}
