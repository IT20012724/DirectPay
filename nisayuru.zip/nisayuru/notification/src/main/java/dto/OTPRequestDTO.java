
  package com.example.notification.dto;

    public class OTPRequestDTO {

        private String phoneNumber;

        // getters and setters
    }

