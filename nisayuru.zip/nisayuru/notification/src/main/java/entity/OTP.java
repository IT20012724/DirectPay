package com.example.notification.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalDateTime;

@Entity
public class OTP {

    @Id
    private String phoneNumber;
    private String otp;
    private LocalDateTime expiryTime;

    // getters and setters
}

