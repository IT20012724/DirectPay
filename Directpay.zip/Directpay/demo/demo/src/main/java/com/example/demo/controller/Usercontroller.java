package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="api/v1/user")
@CrossOrigin
public class Usercontroller {
    @GetMapping("/getUser")
    public String  getUser(){
        return "Nisayuru";

    }
    @PostMapping("/saveUser")
    public String saveUser(){
        return "User(Nisayuru) Saved";
    }
    @PutMapping("/updateUser")
    public String updateUser() {
        return "User(Nisayuru) updated";
    }

    @DeleteMapping("/deleteUser")
    public String deleteUser() {
        return "User(Nisayuru) Deleted";
    }
}
