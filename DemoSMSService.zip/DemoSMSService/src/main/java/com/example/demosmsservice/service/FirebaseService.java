package com.example.demosmsservice.service;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.stereotype.Service;

@Service
public class FirebaseService {
    private final Firestore db;

    public FirebaseService() {
        this.db = FirestoreClient.getFirestore();
    }

    public void saveData(String collectionName, String documentId, Object data) {
        db.collection(collectionName)
                .document(documentId)
                .set(data);
    }
}
