package com.example.demosmsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSmsServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoSmsServiceApplication.class, args);
    }

}
